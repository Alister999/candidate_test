module DRb
  VERSION = "2.2.1"
end
