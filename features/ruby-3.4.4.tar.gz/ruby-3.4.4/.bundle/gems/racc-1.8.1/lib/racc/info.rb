# frozen_string_literal: true
#--
#
#
#
# Copyright (c) 1999-2006 Minero Aoki
#
# This program is free software.
# You can distribute/modify this program under the same terms of ruby.
# see the file "COPYING".
#
#++

module Racc
  VERSION   = '1.8.1'
  Version = VERSION
  Copyright = 'Copyright (c) 1999-2006 Minero Aoki'
end
